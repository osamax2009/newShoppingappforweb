import 'package:flutter/material.dart';
import 'package:untitled/HomePage.dart';
import 'package:untitled/SelectYear.dart';


class Login extends StatefulWidget {

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {


  String _passwordValue = "";
  String _errorText = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child:  Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("مرحبا بك في ثانوية الفارابي \n \n  قم بادخال كلمة المرور",
              style: TextStyle(
                  fontSize: 25,
                  color: Colors.red
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 30,
            ),

            Container(
              margin: EdgeInsets.all(10),
              alignment: Alignment.center,
              height: MediaQuery.of(context).size.height * 0.5,
              width: MediaQuery.of(context).size.width * 0.5,
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: Colors.black,
                      width: 3
                  ),
                  color: Colors.blue
              ),
              child:

                      Column(
                        children: [
                          TextField(
                            obscureText: true,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(

                                hintText: "كلمة المرور",

                                enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                      ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.white),
              ),


            ),
                            onChanged: (value){
                              setState(() {
                                _passwordValue = value;
                              });
                            },
                          ),
                         Spacer(),

                          Container(
                            width: double.infinity,
                            child: ElevatedButton(
                              style:ElevatedButton.styleFrom(
                                primary: Colors.orange
                              ) ,
                              onPressed: (){
                                if (_passwordValue == "master") {
                                  setState(() {
                                    _errorText="" ;
                                  });
                                  Navigator.push(context, MaterialPageRoute(
                                      builder: (context)=>SelectYear()
                                  )
                                  );
                                }else{
                                  setState(() {
                                    _errorText="كلمة المرور خطأ لايمكن المرور" ;
                                  });
                                }

                              },
                              child: Text("موافق"),
                            ),
                          ),
                          Text(_errorText,
                            style: TextStyle(
                              color: Colors.red
                            ),

                          ),

                        ],


              ),
            ),

          ],
        ),
      ),
    );
  }
}
